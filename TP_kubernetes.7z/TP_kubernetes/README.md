# TP_kubernetes
Un TP, voilà
